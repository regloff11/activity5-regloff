const commission = require('./CalculateComission');
const result = commission(70, 80, 90);
console.log(result);